package oprpp2.jmbag0036531975.hw030036531975;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Random;

@WebServlet(name = "background-image", urlPatterns = {"/mi/vrijeme"})
public class ImageServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String img = "../../images/";
        long random = new Random().nextLong();
        Object o = req.getSession().getAttribute("imgSent");

        if (o != null && (o.toString().equals("poz.png") || o.toString().equals("neg.png")))
            img += o.toString();
        else if (random < 0) {
            img += "poz.png";
        } else {
            img += "neg.png";
        }
        req.setAttribute("img", img);
        req.getRequestDispatcher("time.jsp").forward(req, resp);
    }
}
